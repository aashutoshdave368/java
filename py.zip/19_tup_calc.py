def calculate(num1, num2):
    try:
        s = num1 + num2
        d = num1 - num2
        p = num1 * num2
        div = num1 / num2 if num2 != 0 else "Undefined (Div by 0)"
        return (s, d, p, div)
    except Exception as e:
        print(f"Error: {e}")
        return None

results = calculate(10, 5)
if results:
    total, diff, prod, quotient = results
    print(f"Sum: {total}, Difference: {diff}, Product: {prod}, Division: {quotient}")