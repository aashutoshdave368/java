import numpy as np
import matplotlib.pyplot as plt

def create_histogram():
    try:
        data_str = input("Enter numbers separated by space: ")
        data_list = [float(x) for x in data_str.split()]
        arr = np.array(data_list)
        
        plt.hist(arr, bins=5, color='purple', edgecolor='black')
        plt.xlabel("Values")
        plt.ylabel("Frequency")
        plt.title("Histogram of User Input")
        plt.show()
    except ValueError:
        print("Invalid input! Please enter numbers only.")

create_histogram()