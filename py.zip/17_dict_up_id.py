def update_student(d, s_id):
    try:
        if s_id not in d:
            raise KeyError(f"Student ID {s_id} not found.")
            
        print("Update: 1. Name, 2. Marks, 3. Both")
        choice = input("Enter choice: ")
        
        if choice in ['1', '3']:
            d[s_id]['Name'] = input("Enter new name: ")
        if choice in ['2', '3']:
            d[s_id]['Marks'] = float(input("Enter new marks: "))
        print("Update successful:", d[s_id])
    except KeyError as e:
        print(f"Error: {e}")
    except ValueError:
        print("Invalid data type entered for marks.")

# update_student(students_dict, "1")