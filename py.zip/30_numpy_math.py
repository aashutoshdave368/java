import numpy as np

def numpy_advanced_ops():
    a = np.array([[4, 1], [2, 5]])
    b = np.array([[1, 2], [3, 4]])
    
    print("Addition:\n", a + b)
    print("Subtraction:\n", a - b)
    print("Multiplication:\n", a * b)
    print("Division:\n", a / b)
    
    print("\nMax:", a.max(), "| Min:", a.min(), "| Sum:", a.sum())
    print("Argmax (index of max):", a.argmax())
    print("Argmin (index of min):", a.argmin())
    
    print("\nRow-wise sum (axis=1):", a.sum(axis=1))
    print("Column-wise sum (axis=0):", a.sum(axis=0))
    
    flat = a.flatten()
    print("\nFlattened:", flat)
    print("Sorted flattened array:", np.sort(flat))

numpy_advanced_ops()