import numpy as np

def numpy_creation():
    arr1d = np.array([1, 2, 3, 4, 5])
    arr2d = np.array([[1, 2], [3, 4]])
    arr_rand = np.random.rand(3, 3)
    arr_arange = np.arange(0, 10, 2)
    
    for name, arr in zip(["1D", "2D", "Random", "Arange"], [arr1d, arr2d, arr_rand, arr_arange]):
        print(f"{name} Array:\n{arr}\nShape: {arr.shape}, Dtype: {arr.dtype}\n")

numpy_creation()