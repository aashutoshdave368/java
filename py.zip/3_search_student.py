def search_student(filename, search_name):
    try:
        with open(filename, "r") as f:
            for line in f:
                if search_name.lower() in line.lower():
                    print(f"Record found: {line.strip()}")
                    return
            print("Student not found.")
    except FileNotFoundError:
        print("Error: File not found.")

# search_student("students.txt", "Alice")