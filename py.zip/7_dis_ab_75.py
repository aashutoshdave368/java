import csv

def display_above_75(filename):
    try:
        with open(filename, "r") as f:
            reader = csv.DictReader(f)
            print("Students scoring > 75:")
            for row in reader:
                if int(row["Marks"]) > 75:
                    print(f"{row['Name']} - {row['Marks']}")
    except FileNotFoundError:
        print("File not found.")

# display_above_75("students.csv")