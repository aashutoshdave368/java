def delete_student(d, s_id):
    try:
        if s_id not in d:
            raise KeyError(f"Student ID {s_id} does not exist.")
        del d[s_id]
        print(f"Student {s_id} deleted successfully.")
    except KeyError as e:
        print(f"Error: {e}")

# delete_student(students_dict, "1")