def max_min_2d(arr):
    try:
        if not arr or not arr[0]:
            raise ValueError("Array cannot be empty.")
        
        flat_list = [item for sublist in arr for item in sublist]
        if not all(isinstance(x, (int, float)) for x in flat_list):
            raise TypeError("Array must contain numeric values.")
            
        print(f"Max: {max(flat_list)}, Min: {min(flat_list)}")
    except Exception as e:
        print(f"Error: {e}")

# max_min_2d([[1, 5, 3], [8, -2, 4]])