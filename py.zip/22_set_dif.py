def set_difference(setA, setB):
    result = []
    for item in setA:
        if item not in setB:
            result.append(item)
    return set(result)

# print(set_difference({1, 2, 3}, {2, 4}))