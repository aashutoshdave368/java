def update_element(lst):
    try:
        choice = input("Update by (1) Index or (2) Value? ")
        if choice == '1':
            idx = int(input("Enter index: "))
            if idx < 0 or idx >= len(lst):
                raise IndexError("Index out of range.")
            lst[idx] = input("Enter new value: ")
        elif choice == '2':
            old_val = input("Enter value to update: ")
            positions = [i for i, x in enumerate(lst) if str(x) == old_val]
            if not positions:
                print("Value not found.")
                return
            print(f"Value found at positions: {positions}")
            opt = input("Update (1) Specific occurrence or (2) All? ")
            new_val = input("Enter new value: ")
            
            if opt == '1':
                idx = int(input(f"Enter exact index from {positions}: "))
                if idx in positions:
                    lst[idx] = new_val
                else:
                    print("Invalid index chosen.")
            elif opt == '2':
                for i in positions:
                    lst[i] = new_val
        print("Updated List:", lst)
    except ValueError:
        print("Invalid input datatype.")
    except IndexError as e:
        print(e)

# update_element([10, 20, 10, 30])