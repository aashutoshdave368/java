students = {}

while True:
    choice1 = int(input("""\n1 - Insert Data \n2 - Update Data \n3 - Delete Data \n4 - Display \n5 - Exit \n\nEnter your choice : """))

    if choice1 == 1:
        choice2 = int(input("""\n1 - Insert Single Data \n2 - Insert Multiple Data  \n\nEnter your Insert choice : """))
        i = 1
        count = 1

        if choice2 == 2:
            count = int(input("Enter count : "))

        while(i <= count):
            id = int(input("Enter student Id : "))
            if id in students:
                print("ID already exist go for update. ")

            else:
                name = input("Enter Student Name : ")
                marks = int(input("Enter student marks : "))
                students[id] = {"Name" : name, "Marks" : marks} 
                i += 1




    elif choice1 == 2:
        id = int(input("Enter Id you want to update : "))

        if id not in students:
            print("ID doesnot exist. ")

        else:
            choice = int(input("\n1 - Name \n2 - Marks \n3 - Both \nUpdate choice : "))

            if choice in [1,3]:
                name = input("Enter Name : ")
                students[id]["Name"] = name

            if choice in [2,3]:
                marks = int(input("Enter Marks : "))
                students[id]["Marks"] = marks





    elif choice1 == 3:
        delete_id = int(input("Enter ID to delete: "))


        if delete_id in students:
                del students[delete_id]
                print("Deleted Successfully.")

        
        else:
            print("ID doesnt exists.")




    elif choice1 == 4:
        print(f"ID{" "*4}Name{" "*4}Marks")
        print("-"*22)
        for key,value in students.items():
            print(f"{key}{" "*5}{value['Name']}{" "*4}{value['Marks']}")
        pass




    elif choice1 == 5:
        exit()
    


    else:
        print("Enter a valid choice !!")



