def set_union(set1, set2):
    result = list(set1)
    for item in set2:
        if item not in result:
            result.append(item)
    return set(result)

# print(set_union({1, 2}, {2, 3}))