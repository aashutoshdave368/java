def second_max_min(arr):
    try:
        if not arr or len(arr) < 2:
            raise ValueError("List must contain at least two elements.")
        if not all(isinstance(x, (int, float)) for x in arr):
            raise TypeError("List must contain numeric values.")
            
        unique_arr = list(set(arr))
        if len(unique_arr) < 2:
            raise ValueError("Not enough unique elements.")
            
        unique_arr.sort()
        print(f"Second Min: {unique_arr[1]}, Second Max: {unique_arr[-2]}")
    except Exception as e:
        print(f"Error: {e}")

# second_max_min([10, 20, 4, 45, 99])