import pandas as pd
import matplotlib.pyplot as plt

def plot_bar_graph():
    try:
        df = pd.read_csv("students.csv")
        plt.bar(df["Name"], df["Marks"], color='skyblue')
        plt.xlabel("Student Names")
        plt.ylabel("Marks")
        plt.title("Student Marks - Bar Graph")
        plt.show()
    except FileNotFoundError:
        print("Error: File not found.")
    except Exception as e:
        print(f"Error: {e}")

plot_bar_graph()