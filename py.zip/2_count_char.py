def count_characters(filename):
    vowels_list = "AEIOUaeiou"
    try:
        with open(filename, "r") as f:
            for i, line in enumerate(f, 1):
                vowels = sum(1 for char in line if char in vowels_list)
                digits = sum(1 for char in line if char.isdigit())
                consonants = sum(1 for char in line if char.isalpha() and char not in vowels_list)
                
                print(f"Line {i}: Vowels: {vowels}, Consonants: {consonants}, Digits: {digits}")
    except FileNotFoundError:
        print("File not found!")

count_characters("students.txt")