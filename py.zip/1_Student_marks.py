def process_student_text_file():
    filename = "students.txt"
    # Write data
    try:
        with open(filename, "w") as f:
            f.write("Alice,85,CS\nBob,45,IT\nCharlie,92,ECE\nDavid,30,Mech\n")
    except Exception as e:
        print(f"Error writing file: {e}")

    # Read and process
    try:
        with open(filename, "r") as f:
            lines = f.readlines()
            
        max_marks = -1
        top_student = ""
        below_50 = []
        
        for line in lines:
            name, marks_str, dept = line.strip().split(',')
            marks = int(marks_str)
            
            if marks > max_marks:
                max_marks = marks
                top_student = name
            if marks < 50:
                below_50.append(name)
                
        print(f"Top Student: {top_student} ({max_marks} marks)")
        print(f"Students below 50 marks: {', '.join(below_50)}")
        
    except FileNotFoundError:
        print("Error: The file does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

process_student_text_file()