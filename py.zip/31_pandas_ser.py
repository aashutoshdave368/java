import pandas as pd

def pandas_creation():
    # Series from list
    s_list = pd.Series([10, 20, 30], index=['A', 'B', 'C'])
    print("Series from List:\n", s_list)
    
    # Series from dict
    s_dict = pd.Series({'X': 100, 'Y': 200})
    print("\nSeries from Dict:\n", s_dict)
    
    print("\nAccess element 'B':", s_list['B'])
    
    # DataFrame from dict
    data = {'Name': ['John', 'Anna'], 'Marks': [85, 90], 'Age': [20, 21]}
    df = pd.DataFrame(data)
    print("\nDataFrame:\n", df)
    
    # Save to CSV
    df.to_csv("pandas_students.csv", index=False)
    print("\nSaved to pandas_students.csv")

pandas_creation()