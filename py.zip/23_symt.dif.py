def symmetric_difference(set1, set2):
    try:
        # Step 1: Find elements in set1 but not in set2
        diff1 = [item for item in set1 if item not in set2]
        
        # Step 2: Find elements in set2 but not in set1
        diff2 = [item for item in set2 if item not in set1]
        
        # Step 3: Combine them without using union() or |
        result_list = diff1
        for item in diff2:
            if item not in result_list:
                result_list.append(item)
                
        return set(result_list)
    except Exception as e:
        print(f"Error calculating symmetric difference: {e}")
        return None

# Test the function
print("Symmetric Difference:", symmetric_difference({1, 2, 3}, {3, 4, 5}))






# def symmetric_difference(set1, set2):
#     diff1 = set_difference(set1, set2)
#     diff2 = set_difference(set2, set1)
#     return set_union(diff1, diff2)

# # print(symmetric_difference({1, 2, 3}, {3, 4, 5}))