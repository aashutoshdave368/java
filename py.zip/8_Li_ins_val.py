class OutOfRangeError(Exception):
    pass

def insert_element(lst):
    try:
        val = input("Enter value to insert: ")
        choice = input("Insert at (1) End or (2) Specific Position? ")
        
        if choice == '1':
            lst.append(val)
        elif choice == '2':
            pos = int(input("Enter position (index): "))
            if pos < 0 or pos > len(lst):
                raise OutOfRangeError("Index out of bounds!")
            lst.insert(pos, val)
        else:
            print("Invalid choice.")
        print("Updated List:", lst)
    except ValueError:
        print("Error: Position must be an integer.")
    except OutOfRangeError as e:
        print(f"Error: {e}")

# my_list = [10, 20, 30]; insert_element(my_list)