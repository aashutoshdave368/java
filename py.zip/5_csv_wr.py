import csv

def process_csv_students():
    filename = "students.csv"
    data = [["Name", "Marks", "Department"], 
            ["Eve", 88, "IT"], ["Frank", 42, "CS"], ["Grace", 95, "IT"]]
            
    try:
        with open(filename, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(data)
            
        with open(filename, "r") as f:
            reader = csv.DictReader(f)
            max_marks = -1
            top_student = ""
            below_50 = []
            it_students = []
            
            for row in reader:
                marks = int(row["Marks"])
                if marks > max_marks:
                    max_marks = marks
                    top_student = row["Name"]
                if marks < 50:
                    below_50.append(row["Name"])
                if row["Department"] == "IT":
                    it_students.append(row["Name"])
                    
            print(f"Top Student: {top_student}")
            print(f"Below 50: {below_50}")
            print(f"IT Department: {it_students}")
    except FileNotFoundError:
        print("CSV file not found.")

process_csv_students()