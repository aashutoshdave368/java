def is_subset(setA, setB):
    for item in setA:
        if item not in setB:
            return False
    return True

# print(is_subset({1, 2}, {1, 2, 3}))