def matrix_operations(mat1, mat2, op):
    try:
        if len(mat1) != len(mat2) or len(mat1[0]) != len(mat2[0]):
            raise ValueError("Matrix dimensions must match!")
        
        result = []
        for i in range(len(mat1)):
            row = []
            for j in range(len(mat1[0])):
                if not (isinstance(mat1[i][j], (int, float)) and isinstance(mat2[i][j], (int, float))):
                    raise TypeError("Matrices must contain numeric values only.")
                
                if op == '+':
                    row.append(mat1[i][j] + mat2[i][j])
                elif op == '-':
                    row.append(mat1[i][j] - mat2[i][j])
            result.append(row)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None

# m1 = [[1, 2], [3, 4]]; m2 = [[5, 6], [7, 8]]
# print(matrix_operations(m1, m2, '+'))