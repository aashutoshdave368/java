def max_min_1d(arr):
    try:
        if not arr:
            raise ValueError("List cannot be empty.")
        if not all(isinstance(x, (int, float)) for x in arr):
            raise TypeError("List must contain numeric values.")
            
        print(f"Max: {max(arr)}, Min: {min(arr)}")
    except Exception as e:
        print(f"Error: {e}")

# max_min_1d([10, 40, 5, 80])