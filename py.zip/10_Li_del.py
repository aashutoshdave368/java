def delete_element(lst):
    try:
        choice = input("Delete by (1) Index or (2) Value? ")
        if choice == '1':
            idx = int(input("Enter index: "))
            if idx < 0 or idx >= len(lst):
                raise IndexError("Index out of range.")
            del lst[idx]
        elif choice == '2':
            val = input("Enter value to delete: ")
            positions = [i for i, x in enumerate(lst) if str(x) == val]
            if not positions:
                print("Value not found.")
                return
            print(f"Value found at: {positions}")
            opt = input("Delete (1) Specific occurrence or (2) All? ")
            
            if opt == '1':
                idx = int(input(f"Enter index to delete from {positions}: "))
                if idx in positions:
                    del lst[idx]
                else:
                    print("Invalid index chosen.")
            elif opt == '2':
                lst[:] = [x for x in lst if str(x) != val]
        print("Updated List:", lst)
    except ValueError:
        print("Invalid input.")
    except IndexError as e:
        print(e)

# delete_element([5, 15, 25, 15])