import pandas as pd
import matplotlib.pyplot as plt

def plot_line_graph():
    try:
        df = pd.read_csv("students.csv")
        print(df)
        
        plt.plot(df["Name"], df["Marks"], marker='o', color='b', linestyle='-')
        plt.xlabel("Student Names")
        plt.ylabel("Marks")
        plt.title("Student Marks - Line Graph")
        plt.grid(True)
        plt.show()
    except FileNotFoundError:
        print("Error: The CSV file was not found.")
    except KeyError:
        print("Error: Ensure CSV has 'Name' and 'Marks' columns.")

plot_line_graph()