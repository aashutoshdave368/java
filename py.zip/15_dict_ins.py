students_dict = {}

def insert_student():
    try:
        s_id = input("Enter Student ID: ")
        if s_id in students_dict:
            raise ValueError("Student ID already exists!")
        
        name = input("Enter Name: ")
        marks = float(input("Enter Marks: "))
        students_dict[s_id] = {"Name": name, "Marks": marks}
        print("Record added successfully.")
    except ValueError as e:
        print(f"Invalid Input/Error: {e}")

# insert_student()