def set_intersection(set1, set2):
    result = []
    for item in set1:
        if item in set2:
            result.append(item)
    return set(result)

# print(set_intersection({1, 2, 3}, {2, 3, 4}))