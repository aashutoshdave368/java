def uppercase_vowels(filename):
    vowels = "aeiou"
    try:
        with open(filename, "r") as f:
            content = f.read()
        
        modified_content = "".join(char.upper() if char in vowels else char for char in content)
        print("Modified Content:\n", modified_content)
    except FileNotFoundError:
        print("File not found!")

# uppercase_vowels("sample.txt")