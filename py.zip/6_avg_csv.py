import csv

def calculate_average_csv(filename):
    try:
        total_marks = 0
        count = 0
        with open(filename, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                total_marks += int(row["Marks"])
                count += 1
        if count > 0:
            print(f"Average Marks: {total_marks / count:.2f}")
        else:
            print("No data found.")
    except FileNotFoundError:
        print("File not found.")
    except ValueError:
        print("Invalid data format in marks column.")

# calculate_average_csv("students.csv")