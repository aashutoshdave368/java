import numpy as np

def numpy_manipulation():
    arr = np.arange(1, 10).reshape(3, 3)
    print("Reshaped 3x3 Array:\n", arr)
    
    print("\nSpecific element at (1, 1):", arr[1, 1])
    
    print("\nSubarray slicing (First 2 rows, last 2 columns):\n", arr[:2, 1:])

numpy_manipulation()