def display_top_students(d):
    try:
        found = False
        for s_id, details in d.items():
            if details["Marks"] > 75:
                print(f"ID: {s_id}, Name: {details['Name']}, Marks: {details['Marks']}")
                found = True
        if not found:
            print("No student scored more than 75.")
    except Exception as e:
        print(f"Error traversing dictionary: {e}")

# display_top_students({'1': {'Name': 'A', 'Marks': 80}, '2': {'Name': 'B', 'Marks': 60}})