import pandas as pd

def pandas_data_analysis():
    data = {'Name': ['Alice', 'Bob', 'Charlie', 'David'], 
            'Marks': [85, 45, 92, 78], 
            'Age': [19, 22, 21, 20]}
    df = pd.DataFrame(data)
    
    print("Head():\n", df.head(2))
    print("\nShape:", df.shape)
    print("Columns:", df.columns.tolist())
    
    print("\nAccess 'Marks' column:\n", df['Marks'])
    
    print("\nMarks Mean:", df['Marks'].mean())
    print("Marks Max:", df['Marks'].max())
    print("Marks Min:", df['Marks'].min())
    
    print("\nFiltered (Marks > 80 AND Age > 20):\n", df[(df['Marks'] > 80) & (df['Age'] > 20)])
    
    print("\nStatistical Summary:\n", df.describe())

pandas_data_analysis()